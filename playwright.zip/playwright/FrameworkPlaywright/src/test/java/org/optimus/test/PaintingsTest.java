package org.optimus.test;

import org.optimus.base.BaseWebTest;
import org.optimus.pages.Paintings;
import org.testng.annotations.Test;
import com.optimus.constants.MobileConstants;
import com.optimus.constants.PaintingsConstants;

import io.qameta.allure.Description;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PaintingsTest extends BaseWebTest {
    private static final Logger log = LoggerFactory.getLogger(PaintingsTest.class);
    
    @Description("Verify that Painting is getting added to the cart successfully")
    @Test(description = "Verify that Painting is getting added to the cart successfully", priority = 1)
    public void verifyFlightBooking() {
    	Paintings paintings = new Paintings(page);
        try {
        	paintings.paintingSelect();
            log.info(PaintingsConstants.LOG_MSG_PAINTINGS_SELECTED);
        } catch (Exception exception) {
            log.error(MobileConstants.LOG_MSG_TEST_FAILED_TEXT, exception.getMessage());
            throw exception;
        }
    }
}
