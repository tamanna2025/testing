package org.optimus.test;

import org.optimus.base.BaseWebTest;
import org.optimus.pages.FlightBookingRound;
import org.optimus.utilities.ConfigLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import com.optimus.constants.FlightBookingConstants;
import com.optimus.constants.MobileConstants;

import io.qameta.allure.Description;

public class FlightBookingRoundTest extends BaseWebTest {
    private static final Logger log = LoggerFactory.getLogger(FlightBookingRoundTest.class);
    private String fromCity;
    private String toCity;
    
    
    private FlightBookingRound flightBookingRound;
    @Description("Verify user is able to search flight for round trip")
    @Test(description = "Verify user is able to search flight for round trip", priority = 1)
    public void verifyFlightOneWay() {
        String configPath = MobileConstants.PATH;
        fromCity = ConfigLoader.configLoader1(configPath, "fromCity");
        toCity = ConfigLoader.configLoader1(configPath, "toCity");
        flightBookingRound = new FlightBookingRound(page);

        try {
        	flightBookingRound.flightSelect(fromCity, toCity);
	        log.info(FlightBookingConstants.LOG_MSG_FLIGHT_SEARCH_SUCCESS);
        } catch (Exception exception) {
            log.error(FlightBookingConstants.LOG_ERROR_FAILED_TO_SELECT_FLIGHT, exception.getMessage());
            throw exception;
        }
    }
}
