package org.optimus.test;

import org.optimus.base.BaseWebTest;
import org.optimus.pages.SearchProduct;
import org.optimus.utilities.ConfigLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import com.optimus.constants.MobileConstants;
import com.optimus.constants.SearchProductConstants;

import io.qameta.allure.Description;

public class SearchProductTest extends BaseWebTest {
    private static final Logger log = LoggerFactory.getLogger(SearchProductTest.class);
    private String pin;
    private String itemName;
    private SearchProduct searchProduct;

    @Description("Verify that iPhone is getting added to the cart successfully")
    @Test(description = "Verify that iPhone is getting added to the cart successfully", priority = 1)
    public void verifyMobile() {
        String configPath = MobileConstants.PATH;
        pin = ConfigLoader.configLoader1(configPath, "pin");
        itemName = ConfigLoader.configLoader1(configPath,"itemName");
        searchProduct = new SearchProduct(page);

        try {
            searchProduct.mobileSelect(pin, itemName);
            log.info(SearchProductConstants.LOG_MSG_IPHONE_SELECTION_TEXT);
        } catch (Exception exception) {
            log.error(MobileConstants.LOG_MSG_TEST_FAILED_TEXT, exception.getMessage());
            throw exception;
        }
    }
}
