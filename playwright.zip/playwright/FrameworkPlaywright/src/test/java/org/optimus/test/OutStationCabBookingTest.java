package org.optimus.test;

import org.optimus.base.BaseWebTest;
import org.optimus.pages.OutStationCabBooking;
import org.optimus.utilities.ConfigLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import com.optimus.constants.MobileConstants;
import com.optimus.constants.OutStationCabConstants;

import io.qameta.allure.Description;

public class OutStationCabBookingTest extends BaseWebTest {
    private static final Logger log = LoggerFactory.getLogger(OutStationCabBookingTest.class);
    private String pickUp;
    private String dropOff;
    private String enterStop;
    private String name;
    private String mobile;
    private String email;
    
    private OutStationCabBooking outStationCabBooking;
    @Description("Verify user is able to select cab")
    @Test(description = "Verify user is able to select cab", priority = 1)
    public void verifyCab() {
        String configPath = MobileConstants.PATH;
        pickUp = ConfigLoader.configLoader1(configPath, "pickUp");
        dropOff = ConfigLoader.configLoader1(configPath, "dropOff");
        enterStop = ConfigLoader.configLoader1(configPath, "enterStop");
        name = ConfigLoader.configLoader1(configPath, "name");
        mobile = ConfigLoader.configLoader1(configPath, "mobile");
        email = ConfigLoader.configLoader1(configPath, "email");
        outStationCabBooking = new OutStationCabBooking(page);

        try {
        	outStationCabBooking.cabSelect(pickUp, dropOff, enterStop, name, mobile, email );
	        log.info(OutStationCabConstants.LOG_MSG_OPEN_SUCCESS);
        } catch (Exception exception) {
            log.error(OutStationCabConstants.LOG_ERROR_FAILED_TO_SELECT_CAB, exception.getMessage());
            throw exception;
        }
    }
}
