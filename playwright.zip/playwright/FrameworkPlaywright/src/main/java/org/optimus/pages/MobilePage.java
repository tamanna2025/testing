package org.optimus.pages;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

import com.microsoft.playwright.Page;
import com.optimus.constants.GlobalConstants;
import com.optimus.constants.MobileConstants;
import com.optimus.constants.PlantsSaplingsConstants;

import io.qameta.allure.Step;

import org.optimus.utilities.WebUI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MobilePage {
	
	private static final Logger log = LoggerFactory.getLogger(MobilePage.class);
    private final Page page;
    private WebUI webUi;

    public MobilePage(Page page) {
        this.page = page;
        this.webUi = new WebUI(page); 
    }
    @Step("<ul><li>1. Redirect to 'Flipkart site'" + "<ul><li>2. click on 'Electronics'"+ "<ul><li>3.Then click on 'Mi'"
	        + "<ul><li>4.Select 'Mi mobile' "+ "<ul><li>5. Click on 'desired mobile'"
			+ "<ul><li>6. Enter 'pincode' in placeholder." + "<ul><li>7. Click on 'Add to Cart' button"+"</ul>")
    public void mobileSelect(String pin) {
    	log.info(MobileConstants.LOG_MSG_NAVIGATING);

    	webUi.clickWebElement(PlantsSaplingsConstants.MOBILES_XPATH);
        webUi.clickWebElement(MobileConstants.ELECTRONICS_XPATH);
        webUi.clickWebElement(MobileConstants.ELECTRONICS_XPATH);
        webUi.clickWebElement(MobileConstants.MI_XPATH);
		Page popupPage = webUi.waitForPopupAndClick(MobileConstants.PHONE_XPATH);
		log.info(MobileConstants.LOG_MSG_MOBILE_VISIBLE);
		assertThat(popupPage.locator(MobileConstants.PHONE_XPATH));
		log.info(MobileConstants.LOG_MSG_ASSERTION_PASSED_MOBILE);
		webUi.scrollIntoViewIfNeeded(popupPage.locator(MobileConstants.PINCODE_ID));
		log.info(MobileConstants.LOG_MSG_PIN_VISIBLE);
		assertThat(popupPage.locator(MobileConstants.PINCODE_ID)).isVisible();
		log.info(MobileConstants.LOG_MSG_ASSERTION_PASSED_PIN);
		webUi.fillText(popupPage.locator(MobileConstants.PINCODE_ID), pin);
		webUi.clickWebElement(popupPage.locator(MobileConstants.ADD_TO_CART_XPATH), MobileConstants.ADD_TO_CART_XPATH);
		assertThat(popupPage.getByText(PlantsSaplingsConstants.SAVE_FOR_LATER_TEXT)).isVisible();    	
		webUi.waitForTimeout(GlobalConstants.FIVE_SEC_WAIT);
    }
}
