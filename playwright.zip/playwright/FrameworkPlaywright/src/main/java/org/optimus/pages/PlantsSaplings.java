package org.optimus.pages;


import com.microsoft.playwright.Page;
import com.optimus.constants.GlobalConstants;
import com.optimus.constants.MobileConstants;
import com.optimus.constants.PlantsSaplingsConstants;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;


import io.qameta.allure.Step;


import org.optimus.utilities.WebUI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PlantsSaplings {
	
	private static final Logger log = LoggerFactory.getLogger(PlantsSaplings.class);
    private final Page page;
    private WebUI webUi;

    public PlantsSaplings(Page page) {
        this.page = page;
        this.webUi = new WebUI(page); 
    }
    @Step("<ul><li>1. Redirect to 'Flipkart site'" + "<ul><li>2. Click on 'Home & Kitchen'"+ "<ul><li>3.Then click on 'Home & Furniture'"
	        + "<ul><li>4.Click on 'Lawn & Gardening' "+ "<ul><li>5. Click on 'Plants & Planters'"
			+ "<ul><li>6. Sort by 'High to Low'" + "<ul><li>7. Click on 'Add to Cart' button"+"</ul>")
    public void plantSelect() {
    	log.info(MobileConstants.LOG_MSG_NAVIGATING);
    	webUi.clickWebElement(PlantsSaplingsConstants.MOBILES_XPATH);
    	webUi.clickByText(page, PlantsSaplingsConstants.HOME_FURNITURE_TEXT);
    	webUi.assertIsVisibleText(page, PlantsSaplingsConstants.HOME_FURNITURE_TEXT);
    	webUi.clickByText(page, PlantsSaplingsConstants.LAWN_GARDENING_TEXT);
    	webUi.clickByText(page, PlantsSaplingsConstants.PLANTS_PLANTERS_TEXT);
    	webUi.clickWebElement(PlantsSaplingsConstants.PLANTS_SAPLINGS_XPATH);
    	webUi.clickWebElement(PlantsSaplingsConstants.HIGH_TO_LOW_TEXT);
    	Page popupPage = webUi.waitForPopupAndClick(PlantsSaplingsConstants.FIRST_TOP_PLANT_XPATH);
    	webUi.clickWebElement(popupPage.locator(MobileConstants.ADD_TO_CART_XPATH), MobileConstants.ADD_TO_CART_XPATH);
    	assertThat(popupPage.getByText(PlantsSaplingsConstants.SAVE_FOR_LATER_TEXT)).isVisible();    	
    	webUi.waitForTimeout(GlobalConstants.FIVE_SEC_WAIT);
    }
}
