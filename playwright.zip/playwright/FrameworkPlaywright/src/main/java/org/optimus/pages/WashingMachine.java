package org.optimus.pages;


import com.microsoft.playwright.Page;
import com.optimus.constants.GlobalConstants;
import com.optimus.constants.MobileConstants;
import com.optimus.constants.PlantsSaplingsConstants;
import com.optimus.constants.WashingMachineConstants;

import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Step;
import io.qameta.allure.Story;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

import org.optimus.utilities.WebUI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WashingMachine {
	
	private static final Logger log = LoggerFactory.getLogger(WashingMachine.class);
    private final Page page;
    private WebUI webUi;

    public WashingMachine(Page page) {
        this.page = page;
        this.webUi = new WebUI(page); 
    }
    @Step("<ul><li>1. Redirect to 'Flipkart site'" + "<ul><li>2. Click on 'TV & Appliances'"+ "<ul><li>3.Then click on 'Fully Automatic Front Load'"
	        + "<ul><li>4.Select brand as 'LG' "+ "<ul><li>5. Select for 'Family of 4'"
			+ "<ul><li>6. Sort by 'Newest First'" + "<ul><li>7. Click on 'Add to Cart' button"+"</ul>")
    public void washingMachineSelect() {
    	log.info(MobileConstants.LOG_MSG_NAVIGATING);

    	webUi.clickWebElement(PlantsSaplingsConstants.MOBILES_XPATH);
    	webUi.clickWebElement(WashingMachineConstants.TV_APPLIANCE_XPATH);
    	webUi.clickWebElement(WashingMachineConstants.FULLY_AUTOMATIC_XPATH);
    	webUi.clickByText(page, WashingMachineConstants.FAMILY_OF_FOUR_TEXT);
    	webUi.clickWebElement(WashingMachineConstants.LG_XPATH);
    	webUi.assertIsVisibleText(page, WashingMachineConstants.NEWEST_FIRST_XPATH);
    	webUi.clickByText(page, WashingMachineConstants.NEWEST_FIRST_XPATH);
    	Page popupPage = webUi.waitForPopupAndClick(WashingMachineConstants.LG_MACHINE_XPATH);
    	webUi.clickWebElement(popupPage.locator(MobileConstants.ADD_TO_CART_XPATH), MobileConstants.ADD_TO_CART_XPATH);
//    	webUi.clickWebElement(popupPage.locator(WashingMachineConstants.BUY_NOW_XPATH), WashingMachineConstants.BUY_NOW_XPATH);
    	assertThat(popupPage.getByText(PlantsSaplingsConstants.SAVE_FOR_LATER_TEXT)).isVisible();    	
    	webUi.waitForTimeout(GlobalConstants.FIVE_SEC_WAIT);
    }
}
