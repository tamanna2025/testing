package org.optimus.pages;

import com.microsoft.playwright.Page;
import com.optimus.constants.FlightBookingConstants;
import com.optimus.constants.GlobalConstants;
import com.optimus.constants.OutStationCabConstants;

import io.qameta.allure.Step;

import org.optimus.utilities.WebUI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FlightBookingOneWay {
	/**
     * public class for Flight One-way search for web
     */
	private static final Logger log = LoggerFactory.getLogger(FlightBookingOneWay.class);
    private final Page page;
    private WebUI webUi;

    public FlightBookingOneWay(Page page) {
        this.page = page;
        this.webUi = new WebUI(page); 
    }

	@Step("<ul><li>1. Redirect to 'flight'" + "<ul><li>2. Select 'Pickup and drop' station"+ "<ul><li>3. Select '1 Children and 2 adult'"
	        + "<ul><li>4.Click on 'SEARCH FLIGHT' button" + "+</ul>")
	public void flightSelect(String fromCity, String toCity){
        log.info(OutStationCabConstants.LOG_NAVIGATING_TO_GOIBIBO);
        webUi.clickWebElement(OutStationCabConstants.CLOSE_XPATH);
        webUi.clickWebElement(FlightBookingConstants.FROM_XPATH);
        webUi.clickAndFillText(page, FlightBookingConstants.FROM_INPUT_XPATH, fromCity);
        webUi.clickWebElement(FlightBookingConstants.SELECT_ASR_XPATH);
        webUi.clickAndFillText(page, FlightBookingConstants.TO_INPUT_XPATH, toCity);
        webUi.clickWebElement(FlightBookingConstants.SELECT_DEL_XPATH);
        webUi.clickWebElement(FlightBookingConstants.TRAVELLERS_AND_CLASS_XPATH);
        webUi.clickWebElement(FlightBookingConstants.ADD_ADULT_XPATH);
        webUi.clickWebElement(FlightBookingConstants.ADD_CHILD_XPATH);
        webUi.clickWebElement(FlightBookingConstants.DONE_XPATH);
        webUi.assertIsVisibleText(page, FlightBookingConstants.SEARCH_FLIGHT_TEXT);
        webUi.clickWebElement(FlightBookingConstants.SEARCH_FLIGHT_XPATH);
        webUi.waitForTimeout(GlobalConstants.TWO_SEC_WAIT);
	}
}
    


