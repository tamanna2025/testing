package com.optimus.constants;

public class OutStationCabConstants {
	/**
     * public class OutstationCabConstant for Web
     */
	
	/**
     * location WebElements Locators
     */
	public static final String CLOSE_XPATH = "//span[@class=\"logSprite icClose\"]";
	
	public static final String CAB_XPATH = "//span[text()=\"Cabs\"]";
	
	public static final String PICKUP_XPATH = "//input[@placeholder=\"Enter Pickup location\"]";
	
	public static final String PICKUP_AREA_XPATH = "//input[@placeholder=\"Enter Pickup location (Area, street or landmark)\"]";
	
	public static final String NOIDA_XPATH = "//p[text()=\"SUPERTECH ECOCITI, Sector 137, Noida, Uttar Pradesh, India\"]";
	
	public static final String DROP_XPATH = "//input[@placeholder=\"Enter Drop location\"]";
	
	public static final String DROP_AREA_XPATH = "//input[@placeholder=\"Enter Drop location (Area, street or landmark)\"]";
	
	public static final String ASR_XPATH = "//p[text()=\"Amritsar, Punjab, India\"]";
	
	public static final String ADD_STOP_XPATH = "//div[text()=\"+ Add Stops\"]";
	
	public static final String ENTER_STOP_ONE_XPATH = "//input[@placeholder=\"Enter stop 1\"]";
	
	public static final String CHANDIGARH_XPATH = "//p[text()=\"Chandigarh, India\"]";
	
	public static final String SEARCH_CAB_XPATH = "//button[text()=\"SEARCH CABS\"]";
	
	public static final String SELECT_CAB_XPATH = "(//button[contains(text(),'SELECT')])[1]";
	
	public static final String UPDATE_SEARCH_XPATH = "//p[text()=\"UPDATE SEARCH\"]";
	
	public static final String ENTER_NAME_XPATH = "//input[@placeholder=\"Enter Full Name\"]";
	
	public static final String ENTER_MOBILE_NUMBER_XPATH = "//input[@placeholder=\"Enter Mobile Number\"]";
	
	public static final String ENTER_EMAIL_XPATH = "//input[@placeholder=\"Enter Email\"]";
	
	public static final String PROCEED_TO_PAY_XPATH = "//div[@class=\"pymntCmp_btm\"]";
	
	public static final String BOOK_ONLINE_CAB_TEXT = "Book Online Cab";
	
	public static final String SEARCH_CAB_TEXT = "SEARCH CABS";
	
	public static final String TRAVELLER_DETAILS_TEXT = "Traveller details";
	
	public static final String GRAND_TOTAL_TEXT = "Grand Total";
	
	/**
     * Test Data
     */
    public static final String TEST_DATA_PICKUP = "pickUp";
    
    public static final String TEST_DATA_DROPOFF = "dropOff";
    
    public static final String TEST_DATA_ENTERSTOP = "enterStop";
    
    public static final String TEST_DATA_NAME = "name";
    
    public static final String TEST_DATA_MOBILE_NUMBER = "mobileNumber";
    
    /**
     * log Messages
     */
	public static final String LOG_MSG_OPEN_SUCCESS = "Cab selection successful";
	
	public static final String LOG_ERROR_FAILED_TO_SELECT_CAB = "Cab Selection failed";
	
	public static final String LOG_NAVIGATING_TO_GOIBIBO = "Navigating to goibibo";
	
}

