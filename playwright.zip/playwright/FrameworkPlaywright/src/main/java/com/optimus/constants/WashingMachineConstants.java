package com.optimus.constants;

public class WashingMachineConstants {
	/**
     * public class WashingMachineConstants for Web
     */
	
	/**
     * Washing Machine WebElements Locators
     */
	
	public static final String TV_APPLIANCES_XPATH = "//img[@alt =\"TVs & Appliances\"]";
	
	public static final String TV_APPLIANCE_XPATH = "//span[text()=\"TVs & Appliances\"]";
	
	public static final String FULLY_AUTOMATIC_XPATH = "//a[@title=\"Fully Automatic Front Load\"]";
	
	public static final String FAMILY_OF_FOUR_TEXT = "Family of 4";
	
	public static final String LG_XPATH ="//div[text()=\"LG\"]";
	
	public static final String NEWEST_FIRST_XPATH = "Newest First";
	
	public static final String BUY_NOW_XPATH = "//button[text()=\"Buy Now\"]";
	
	public static final String LG_MACHINE_XPATH = "//div[text()=\"LG 8 kg with Wi-Fi Enabled,Steam Fully Automatic Front Load Washing Machine with In-built Heater Grey,...\"]";

	//Log Messages
	public static final String LOG_MSG_WASHING_MACHINE_SELECTED ="LG washing machine selected successfully";


}
