package com.optimus.constants;

public class PaintingsConstants {
	
	/**
     * public class PaintingsConstants for Web
     */
	
	/**
     * Paintings WebElements Locators
     */
	public static final String PEACOCK_PAINTING_XPATH = "//a[@title=\"saf peacock nature theme for living room, wall decoration Digital Reprint 18 inch x 30 inch Painting\"]"; 
	
	public static final String PAINTINGS_TEXT = "Paintings";
	
	//log messages
	
	public static final String LOG_MSG_PAINTINGS_SELECTED = "Painting is selected successfully";

}
