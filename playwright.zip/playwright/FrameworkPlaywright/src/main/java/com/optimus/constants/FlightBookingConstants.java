package com.optimus.constants;

public class FlightBookingConstants {
	/**
     * Flight WebElements Locators
     */
    public static final String FLIGHT_XPATH = "//span[text()=\"Flights\"]";
    
    public static final String ROUND_TRIP_XPATH = "//p[text()=\"Round-trip\"]";
    
    public static final String FROM_XPATH = "//span[text()=\"From\"]";
    
    public static final String FROM_INPUT_XPATH = "//span[text()=\"From\"]//following-sibling::input";
    
    public static final String SELECT_ASR_XPATH = "//span[text()=\"Amritsar, India\"]";
    
    public static final String TO_INPUT_XPATH = "//span[text()=\"To\"]//following-sibling::input";
    
    public static final String SELECT_DEL_XPATH = "//span[text()=\"New Delhi, India\"]";
    
    public static final String TRAVELLERS_AND_CLASS_XPATH = "//span[text()=\"Travellers & Class\"]";
    
    public static final String ADD_ADULT_XPATH = "//p[text()=\"(Aged 12+ yrs)\"]//following::span[3]";
    
    public static final String ADD_CHILD_XPATH = "//p[text()=\"(Aged 2-12 yrs)\"]//following::span[3]";
    
    public static final String ADD_INFANT_XPATH = "(//p[text()=\"(Below 2 yrs)\"]//following::span)[3]";
    
    public static final String PREMIUM_ECONOMY_XPATH = "//li[text()=\"premium economy\"]";
    
    public static final String DONE_XPATH = "//a[text()=\"Done\"]";
    
    public static final String SEARCH_FLIGHT_XPATH = "//span[text()=\"SEARCH FLIGHTS\"]";
    
    public static final String SEARCH_FLIGHT_TEXT = "SEARCH FLIGHTS";
    /**
     * Test Data
     */
    public static final String TEST_DATA_FROM_CITY = "fromCity";
    
    public static final String TEST_DATA_TO_CITY = "toCity";
    
    /**
     * log Messages
     */
    public static final String LOG_MSG_FLIGHT_SEARCH_SUCCESS = "Flight searching done successfully";
    
    public static final String LOG_MSG_OPEN_SUCCESS = "";
    
    public static final String LOG_ERROR_FAILED_TO_SELECT_FLIGHT = "Failed to select flight";
    
}
