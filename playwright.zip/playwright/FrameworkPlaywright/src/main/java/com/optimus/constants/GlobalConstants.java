package com.optimus.constants;

public class GlobalConstants {
	
	/**
     * Global Constants
     */
	public static final int FIVE_SEC_WAIT = 5000;
	
	public static final int ONE_SEC_WAIT = 1000;
	
	public static final int TWO_SEC_WAIT = 2000;
	
	public static final String LOG_MSG_CLICKING = "Clicking on element: ";

    public static final String LOG_MSG_ENTERING_TEXT = "Entering text";
    
    public static final String LOG_MSG_COLON = " : ";
    
    public static final String LOG_MSG_ASSERTION_FAILED = "Assertion failed while clicking on element";
    
    public static final String LOG_MSG_CLICKING_FILLING = "Error occurred while clicking and filling text: ";
    
    public static final String LOG_MSG_CLICKING_PLACEHOLDER = "Clicking on the element with placeholder: ";
    
    public static final String LOG_MSG_FILLING_TEXT = "Filling text: ";
    
    public static final String LOG_MSG_PRESS_ENTER_TEXT = "Pressing Enter on the element with placeholder: ";

    public static final String LOG_MSG_CLICKING_TEXT = "Clicking on the element with text: ";
    
    public static final String LOG_MSG_CLICKED_TEXT = "Clicked on the element successfully.";
    
    public static final String LOG_MSG_ERROR_CLICKING_TEXT = "Error clicking on the element: ";
    
    public static final String LOG_MSG_ASSERT_PRESENCE = "Asserting the presence of ";
    
    public static final String LOG_MSG_SCROLLING = "Scrolling to find ";

}