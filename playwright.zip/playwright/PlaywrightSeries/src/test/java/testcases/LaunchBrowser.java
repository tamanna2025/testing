package testcases;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.List;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.options.Cookie;

public class LaunchBrowser {

	public static void main(String[] args) throws InterruptedException {
		
		//to get actual size of screen at runtime (one way)
//		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
//		double width = screenSize.getWidth();
//		double height = screenSize.getHeight();
//		
//		System.out.println(width+"---"+height);
		
		Playwright playwright = Playwright.create();
		
		ArrayList<String> arguments = new ArrayList<>();
        arguments.add("--start-maximized");
//        arguments.add("--incognito");
        Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setChannel("chrome").setHeadless(false).setArgs(arguments));
        // Create a new incognito browser context
//        BrowserContext context = browser.newContext(new Browser.NewContextOptions());
        
        BrowserContext context = browser.newContext();

//        BrowserContext context = browser.newContext(new Browser.NewContextOptions().setIsIncognito(true));

		
		
//		ArrayList<String> arguments = new ArrayList<>();
//		arguments.add("--start-maximized");
//		Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setChannel("chrome").setHeadless(false).setArgs(arguments));
//		BrowserContext context = browser.newContext(new Browser.NewContextOptions().setViewportSize(null));
//		BrowserContext context = browser.newContext();
//		BrowserContext context = browser.newContext(new Browser.NewContextOptions().setIsIncognito(true));

//		has context menu
//		BrowserContext browserContext = browser.newContext(new Browser.NewContextOptions().setViewportSize((int)width,(int)height));
		Page page = context.newPage();
		page.navigate("https://amazon.com");
		System.out.println(page.title());
		List<Cookie> cookies = context.cookies();
		if (cookies.isEmpty()) {
		     System.out.println("Browser is running in incognito mode: No cookies found.");
		} else {
		     System.out.println("Browser is not running in incognito mode: Cookies found.");
		}
		Thread.sleep(15000);
		playwright.close(); //close session
	}
}