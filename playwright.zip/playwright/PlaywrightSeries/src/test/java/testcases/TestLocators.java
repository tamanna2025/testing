package testcases;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class TestLocators {

	public static void main(String[] args) throws InterruptedException {
		
		Playwright playwright = Playwright.create();
		Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
		Page page = browser.newPage();
		page.navigate("http://gmail.com");
		page.locator("#identifierId").fill("trainer@way2automation.com");
		page.locator("text='Next'").click();
		page.locator("[type=password]").fill("dfvbgfvds"); 
		page.locator("text='Next'").click();
		Thread.sleep(15000);		
		page.close();
		playwright.close();
	}

}
