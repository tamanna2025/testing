package testcases;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

import org.testng.annotations.Test;

public class Assertions {
	@Test
	public void AssertTest() {
		
		Playwright playwright = Playwright.create();
		Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
		Page page = browser.newPage();
		page.navigate("http://www.tizag.com/htmlT/htmlcheckboxes.php");
		assertThat(page).hasURL("http://www.tizag.com/htmlT/htmlcheckboxes.php");
		assertThat(page).hasTitle("HTML Tutorial - Checkboxes");
		assertThat(page.locator("(//input[@value=\"soccer\"])[2]")).isChecked();
		page.close();
		browser.close();
		playwright.close();

	}

}
