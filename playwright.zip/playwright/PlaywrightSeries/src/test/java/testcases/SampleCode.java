 package testcases;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.*;

public class SampleCode {

	public static void main(String[] args) {
		try (Playwright playwright = Playwright.create()) {
            // Launch Chrome
            Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));

            // Create a new incognito context (simply omit options for a default context)
            BrowserContext context = browser.newContext();
            
            // Create a new page in that context
            Page page = context.newPage();
            
            // Navigate to a URL
            page.navigate("https://amazon.com");
            
            // Perform any actions here...

            // Close the browser
            browser.close();
        }
	}

}
