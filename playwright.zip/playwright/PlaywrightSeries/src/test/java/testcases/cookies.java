package testcases;

import java.util.List;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.options.Cookie;

public class cookies {

    public static void main(String[] args) throws InterruptedException {
    	  boolean isIncognito = true;
        // Initialize Playwright
        Playwright playwright = Playwright.create();
        
        // Launch the browser with the specified options
        Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions()
            .setChannel("chrome")
            .setHeadless(false));

        // Create a new browser context (acts like incognito)
        BrowserContext context = browser.newContext();

        // Check for cookies before navigation
        List<Cookie> initialCookies = context.cookies();
        System.out.println("Initial cookies count (should be 0): " + initialCookies.size());

        // Create a new page in the context
        Page page = context.newPage();
        
        // Navigate to the URL
        page.navigate("https://amazon.com");
        System.out.println("Page title: " + page.title());

        // Check for cookies after navigation
        List<Cookie> cookiesAfterNavigation = context.cookies();
        System.out.println("Cookies count after navigation: " + cookiesAfterNavigation.size());
        
        
        if (isIncognito) {
            System.out.println("Browser is running in incognito mode.");
        } else {
            System.out.println("Browser is not running in incognito mode.");
        }

        
        // Keep the browser open for 15 seconds
        Thread.sleep(15000);

        // Close Playwright session
        context.close();
        playwright.close(); 
    }
}
