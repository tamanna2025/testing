package testcases;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class HandlingCheckboxes {

	public static void main(String[] args) throws InterruptedException {
		
		Playwright playwright = Playwright.create();
		Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
		Page page = browser.newPage();
		page.navigate("http://www.tizag.com/htmlT/htmlcheckboxes.php");
			
		Locator block = page.locator("//h2[text()=\"HTML Checkbox Form:\"]//following::div[1]");
		
		Locator checkboxes = block.locator("[type='checkbox']");
		
		for(int i=0;i<checkboxes.count();i++) {
			checkboxes.nth(i).click();
		}
		System.out.println(checkboxes.count());
		Thread.sleep(2000);
		page.close();
		browser.close();

	}

}
