package mobile.Appium;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.Duration;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

public class BaseTest {
	public AndroidDriver driver;
	public AppiumDriverLocalService service;
	
	@BeforeClass
	public void ConfigureAppium() throws MalformedURLException, URISyntaxException {
//		service = new AppiumServiceBuilder().withAppiumJS(new File("C:\\Users\\Tamanna Sharma\\AppData\\Roaming\\npm\\node_modules\\appium\\build\\lib\\main.js")).withIPAddress("127.0.0.1").usingPort(4723).build(); 
//		
//		//.withArgument(() -> "--chromedriver-autodownload").
//		service.start();
		UiAutomator2Options options = new UiAutomator2Options();
        options.setDeviceName("Tamanna Phone API 34");
//        options.setChromedriverExecutable("C:\\Users\\Tamanna Sharma\\Downloads\\chromedriver_win32");
//        options.setCapability("chromedriverExecutable","C:\\Users\\Tamanna Sharma\\.m2\\repository\\org\\seleniumhq\\selenium\\selenium-chrome-driver\\4.23.1");
//        options.setChromedriverExecutable("C:\\Users\\Tamanna Sharma\\Downloads\\chromedriver-win64");
        options.setApp("C:\\Users\\Tamanna Sharma\\eclipse-workspace\\Appium\\src\\test\\java\\resources\\ApiDemos-debug.apk");
		driver = new AndroidDriver(new URI("http://127.0.0.1:4723").toURL(),options); 
		driver.manage().timeouts().implicitlyWait(Duration.ofMinutes(20));
		
	}
	@AfterClass
	public void tearDown() {
		driver.quit();
//		service.stop();
	}
}