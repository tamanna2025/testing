package mobile.Appium;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;

public class ActionBar extends BaseTest{
	@Test
	public void ActionBarTest() {
		driver.findElement(AppiumBy.accessibilityId("App")).click();
		driver.findElement(AppiumBy.accessibilityId("Action Bar")).click();
		driver.findElement(AppiumBy.accessibilityId("Display Options")).click();
		driver.findElement(AppiumBy.xpath("//android.widget.Button[@content-desc=\"DISPLAY_USE_LOGO\"]")).click();
		driver.findElement(AppiumBy.xpath("//android.widget.Button[@content-desc=\"DISPLAY_SHOW_HOME\"]")).click();
		WebElement ele = driver.findElement(AppiumBy.className("android.widget.ImageView"));
		Assert.assertTrue(ele.isDisplayed());
		driver.findElement(AppiumBy.xpath("//android.widget.Button[@content-desc=\"DISPLAY_SHOW_CUSTOM\"]")).click();
		String customViewBtn = driver.findElement(AppiumBy.accessibilityId("Custom View!")).getText();
		Assert.assertEquals(customViewBtn, "Custom View!");
	}
}
