package mobile.Appium;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.common.collect.ImmutableMap;

import io.appium.java_client.AppiumBy;


public class Fragment extends BaseTest{
	@Test
	public void FragmentTest() {
		driver.findElement(AppiumBy.accessibilityId("App")).click();
		driver.findElement(AppiumBy.accessibilityId("Fragment")).click();
		driver.findElement(AppiumBy.accessibilityId("Context Menu")).click();
		WebElement element = driver.findElement(AppiumBy.accessibilityId("Long press me"));
		//duration is in ms
		((JavascriptExecutor) driver).executeScript("mobile: longClickGesture", ImmutableMap.of(
			    "elementId", ((RemoteWebElement) element).getId(),"duration",2000
			));	
		driver.findElement(AppiumBy.xpath("//android.widget.TextView[@resource-id=\"android:id/title\" and @text=\"Menu A\"]")).click();
		String toastMsg = driver.findElement(AppiumBy.xpath("//android.widget.Toast")).getText();
		Assert.assertEquals(toastMsg, "Item 1a was chosen");
	}
}
