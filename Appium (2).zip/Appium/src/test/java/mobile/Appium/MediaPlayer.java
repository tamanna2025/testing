package mobile.Appium;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;

public class MediaPlayer extends BaseTest{
	@Test
	public void MediaPlayerTest() throws InterruptedException {
		driver.findElement(AppiumBy.accessibilityId("Media")).click();
		driver.findElement(AppiumBy.xpath("//android.widget.TextView[@content-desc=\"MediaPlayer\"]")).click();
		driver.findElement(AppiumBy.xpath("//android.widget.Button[@content-desc=\"Play Audio from Resources\"]")).click();	
		Thread.sleep(1000);
		String playingAudio = driver.findElement(AppiumBy.xpath("//android.widget.TextView[@text=\"Playing audio...\"]")).getText();
		Assert.assertEquals(playingAudio,"Playing audio...");	
	}
}
