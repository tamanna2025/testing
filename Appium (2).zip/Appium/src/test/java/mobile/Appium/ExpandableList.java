package mobile.Appium;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.common.collect.ImmutableMap;

import io.appium.java_client.AppiumBy;

public class ExpandableList extends BaseTest {
	@Test
	public void ExpandableListTest() {
		driver.findElement(AppiumBy.accessibilityId("Views")).click();
		driver.findElement(AppiumBy.accessibilityId("Expandable Lists")).click();
		driver.findElement(AppiumBy.accessibilityId("1. Custom Adapter")).click();
		driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"People Names\")")).click();
		WebElement chuck = driver.findElement(AppiumBy.xpath("//android.widget.TextView[@text=\"Chuck\"]"));
		((JavascriptExecutor) driver).executeScript("mobile: longClickGesture", ImmutableMap.of(
			    "elementId", ((RemoteWebElement) chuck).getId(),"duration",2000
			));
		driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Sample action\")")).click();
		String toastMsg =  driver.findElement(AppiumBy.xpath("//android.widget.Toast[@text=\"Chuck: Child 2 clicked in group 0\"]")).getText();
		String expectedText = "Chuck: Child 2 clicked in group 0";
		Assert.assertEquals(toastMsg,expectedText);
	}
}
