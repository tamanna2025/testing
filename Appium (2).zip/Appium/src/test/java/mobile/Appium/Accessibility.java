package mobile.Appium;

import org.junit.Assert;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;

public class Accessibility extends BaseTest{
	@Test
	public void AccessibilityTest() throws InterruptedException {
		driver.findElement(AppiumBy.accessibilityId("Accessibility")).click();
		driver.findElement(AppiumBy.accessibilityId("Accessibility Node Querying")).click();
		driver.findElement(AppiumBy.xpath("(//android.widget.CheckBox[@resource-id=\"io.appium.android.apis:id/tasklist_finished\"])[1]")).click();
		driver.findElement(AppiumBy.xpath("(//android.widget.CheckBox[@resource-id=\"io.appium.android.apis:id/tasklist_finished\"])[5]")).click();		
		boolean isDoTaxesChecked = driver.findElement(AppiumBy.xpath("(//android.widget.CheckBox[@resource-id=\"io.appium.android.apis:id/tasklist_finished\"])[5]")).getAttribute("checked") != null;
		Assert.assertTrue(isDoTaxesChecked);
	}
}
