package mobile.Appium;

import org.junit.Assert;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;

public class Views extends BaseTest{
	@Test
	public void ViewsTest(){
		driver.findElement(AppiumBy.accessibilityId("Views")).click();
		driver.findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"ImageView\"))")).click();
		boolean dog = driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().className(\"android.widget.ImageView\").instance(0)")) != null;
		Assert.assertTrue(dog);
	}
}
