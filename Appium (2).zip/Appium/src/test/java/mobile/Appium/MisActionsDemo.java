
package mobile.Appium;


import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.common.collect.ImmutableMap;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.Activity;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;


public class MisActionsDemo extends BaseTest {
	@Test
	public void AppiumTest() throws InterruptedException {
		//adb shell dumpsys window | grep -E 'mCurrentFocus'  -> MAC
		//adb shell dumpsys window | find "mCurrentFocus" -> Windows
		
		//App package and activity
		((JavascriptExecutor) driver).executeScript("mobile: startActivity", ImmutableMap.of("intent","io.appium.android.apis/io.appium.android.apis.preference.PreferenceDependencies"));
	
//		driver.findElement(AppiumBy.accessibilityId("Preference")).click();
//		driver.findElement(AppiumBy.xpath("//android.widget.TextView[@content-desc=\"3. Preference dependencies\"]")).click();
		driver.findElement(AppiumBy.id("android:id/checkbox")).click();
		//landscape mode
//		DeviceRotation landScape = new DeviceRotation(0,0,90);
//		driver.rotate(landScape);
		
		driver.findElement(AppiumBy.xpath("(//android.widget.RelativeLayout)[2]")).click();
		String alertTitle = driver.findElement(AppiumBy.id("android:id/alertTitle")).getText();
		Assert.assertEquals(alertTitle,"WiFi settings");
		//copy paste
		driver.setClipboardText("Tamanna Sharma");
		driver.findElement(AppiumBy.id("android:id/edit")).sendKeys(driver.getClipboardText());

		driver.findElement(AppiumBy.id("android:id/button1")).click();
		driver.pressKey(new KeyEvent(AndroidKey.BACK));
		driver.pressKey(new KeyEvent(AndroidKey.HOME));
	
	}	
}
