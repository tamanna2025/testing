package mobile.Appium;

import org.junit.Assert;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;

public class AutoComplete extends BaseTest {
	@Test
	public void AutoCompleteTest() {
		driver.findElement(AppiumBy.accessibilityId("Views")).click();
		driver.findElement(AppiumBy.accessibilityId("Auto Complete")).click();
		driver.findElement(AppiumBy.xpath("//android.widget.TextView[@content-desc='1. Screen Top']")).click();
		driver.findElement(AppiumBy.className("android.widget.AutoCompleteTextView")).sendKeys("India");
		boolean focus = driver.findElement(AppiumBy.accessibilityId("Give me Focus")) !=null ;
		Assert.assertTrue(focus);
	}
}
