package mobile.Appium;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.annotations.Test;

import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;

public class MobileBrowserTest extends MobileBrowserBaseTest {
	
	@Test
	public void browserTest() throws InterruptedException {
		
		driver.get("http://amazon.com");
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Pen");
		driver.findElement(By.xpath("//input[@value=\"Go\"]")).click();
		Thread.sleep(4000);	
	}
}
