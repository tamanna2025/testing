package mobile.Appium;
import org.testng.annotations.Test;
import io.appium.java_client.AppiumBy;

public class DateWidget extends BaseTest {
	@Test
	public void DateWidgetTest() {
		driver.findElement(AppiumBy.accessibilityId("Views")).click();
		driver.findElement(AppiumBy.accessibilityId("Date Widgets")).click();
		driver.findElement(AppiumBy.xpath("//android.widget.TextView[@content-desc=\"1. Dialog\"]")).click();
		driver.findElement(AppiumBy.xpath("//android.widget.Button[@content-desc=\"change the date\"]")).click();
		driver.findElement(AppiumBy.xpath("//android.view.View[@content-desc=\"24 September 2024\"]")).click();
		driver.findElement(AppiumBy.xpath("//android.widget.Button[@resource-id=\"android:id/button1\"]")).click();
		driver.findElement(AppiumBy.xpath("//android.widget.Button[@content-desc=\"change the time\"]")).click();
		driver.findElement(AppiumBy.xpath("//android.widget.RadialTimePickerView.RadialPickerTouchHelper[@content-desc=\"2\"]")).click();
		driver.findElement(AppiumBy.accessibilityId("Switch to text input mode for the time input.")).click();
		driver.findElement(AppiumBy.id("android:id/input_minute")).sendKeys("30");
		driver.findElement(AppiumBy.id("android:id/button1")).click();
		System.out.println(driver.findElement(AppiumBy.id("io.appium.android.apis:id/dateDisplay")).getText());
	}
}
